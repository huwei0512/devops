#encoding:utf-8

from flask import Flask
from flask import render_template
import loganalysis


app = Flask(__name__)

@app.route('/')
def index():
    return 'hello,reboot'


@app.route("/logs/")
def logs():
    logfile = "/root/example.log"

    rt_list = loganalysis.get_topn(logfile=logfile)
    return render_template('logs.html')


if __name__ == '__main__':
    app.run(host="0.0.0.0",port=9003)